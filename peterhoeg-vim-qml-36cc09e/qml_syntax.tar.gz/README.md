# QML syntax file for VIM

I take absolutely no credit for this - all I did was write the ftdetect line and package it. 

The actual syntax highlight file was done by Warwick Allison.

## How to use
I strongly suggest you use the excellent [pathogen tool](http://github.com/tpope/vim-pathogen) from Tim Pope and clone this repos or add it as a submodule under your bundle directory.

Enjoy,
Peter Hoeg
